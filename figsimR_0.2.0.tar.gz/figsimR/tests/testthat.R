library(testthat)
library(figsimR)

test_check("figsimR")
